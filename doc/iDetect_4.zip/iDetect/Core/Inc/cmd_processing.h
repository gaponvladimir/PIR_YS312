#ifndef _CMD_PROCESSING_H
#define _CMD_PROCESSING_H

#include "lwrb.h"

// Define our type for circular buffer that will equal to Tilen MAJERLE implementation
#define	ringbuff_t	lwrb_t

#define CMD_BUF_SIZE 64

#define CMD_ANSWER_SET_LENGTH(length)		{answer_to_command[1] = (unsigned char)(length >> 8); answer_to_command[2] = (unsigned char) length;}
#define CMD_ANSWER_SET_COMMAND(cmd)			answer_to_command[3] = cmd
#define CMD_ANSWER_SET_STATUS(status)		answer_to_command[4] = (unsigned char) status
#define CMD_ANSWER_SET_DATA(data, len)		memcpy(&answer_to_command[5], data, len)


typedef enum {
	CMD_STATUS_SUCCESS         = 0, /**< Command executed successfully */
	CMD_STATUS_ERROR           = 1, /**< Command executed with error */
	CMD_STATUS_UNKNOWN         = 2, /**< Command is not supported by our processing */
	CMD_STATUS_BUFFER_TO_SMALL = 3, /**< Buffer used for construct is smaller then received data from peripheral */
	CMD_STATUS_TIMEOUT         = 4, /**< Waiting timeout elapsed during communication */
} CMD_ANSWER_STATUS;

/** Answers for functions that process received packet as [SOF][LENGTH][CMD][DATA][CRC] */
typedef enum {
	BUF_PROC_OK = 0,				/**< Packet exist in circular buffer and successfully validated */
	BUF_PROC_DATA_ABSENT = -1,		/**< Data is absent in the circular buffer */
	BUF_PROC_SOF_INVALID = -2,		/**< First byte in circular buffer is not equal to the SOF. During processing all data purged */
	BUF_PROC_IN_RECEPTION = -3,		/**< Data partially received (received size is less then size of overall length header+cmd+CRC) */
	BUF_PROC_LENGTH_INVALID = -4,	/**< Specified in packet length is not valid (greater then buffer size) */
	BUF_PROC_CRC_INVALID = -5		/**< CRC calculated for packet is not equal to the included in the packet */
} BUF_PROCESSING_STATUS;


/**
 * Default processing timeout in ms. If after reception of the SOF we don't
 * receive all data via communication interface(s) or don't receive
 * answer form the board peripheral we need to abort command
 */
#define DEFAULT_PROCESSING_TIMEOUT			1000

#define CMD_SOF                             0x0     /**< Start of frame character used as first byte in communication protocol */
#define CMD_BUFFER_SIZE                     1024    /**< Size of the command buffer in bytes */
#define CMD_SOF_FIELD_SIZE                  0x01    /**< Size of the SOF field in a header section in bytes */
#define CMD_PACKET_LENGTH_FIELD_SIZE	    0x02    /**< Size of the packet length field in a header section in bytes */
#define CMD_COMMAND_FIELD_SIZE              0x01    /**< Size of the command field in the data section in bytes */
#define CMD_LRC_FIELD_SIZE                  0x01    /**< Size of the LRC field in the data section in bytes */
#define CMD_STATUS_FIELD_SIZE               0x01    /**< Size of the status field that is added as first byte to data for the answer to command */
#define CMD_HEADER_SIZE                     (CMD_SOF_FIELD_SIZE + CMD_PACKET_LENGTH_FIELD_SIZE) /**< Size of the packet header that includes: [SOF][DATA LENGTH] */

/** Polynomial used for calculation CRC8 */
#define CMD_CRC_POL                         0x18


// Command codes for used in our communication protocol
#define CMD_GET_SERIAL_NUMBER               0x01    /**< Get device serial number as string */
#define CMD_GET_HARDWARE_VERSION            0x02    /**< Get hardware version as string X.Y */
#define CMD_GET_FIRMWARE_VERSION            0x03    /**< Get firmware version as string MAJOR.MINOR.REVISION */

#define CMD_SET_SYSTEM_TIME                 0x21    /**< Set system time  */
#define CMD_GET_SYSTEM_TIME                 0x22    /**< Get system time  */

#define CMD_GET_ADC_DATA 					0xA2	/**< Get ADC value  */



unsigned int cmd_get_amount_in_queue(ringbuff_t *cmd_buf);
BUF_PROCESSING_STATUS cmd_check_for_sof(ringbuff_t *cmd_buf);
int cmd_get_data_length(ringbuff_t *cmd_buf);
int cmd_check_if_command_received(ringbuff_t *cmd_buf, unsigned int len);
void cmd_purge_queue_buffer(ringbuff_t *cmd_buf);
BUF_PROCESSING_STATUS cmd_validate_packet(ringbuff_t *cmd_buf);
int cmd_process_received_command(void);
unsigned char* cmd_get_answer_for_command(void);
int cmd_wait_for_command_answer(unsigned int timeout_start, unsigned int timeout_to_wait);
void cmd_idle_operation();

#endif // _CMD_PROCESSING_H
