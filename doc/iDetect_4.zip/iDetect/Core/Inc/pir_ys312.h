/*
 * pir_ys312.h
 *
 *  Created on: Apr 28, 2026
 *      Author: BBoiko
 */

#ifndef PIR_YS312_H_
#define PIR_YS312_H_

#include "main.h"

/* GPIO для DOCI лінії */
#define PIR_DOCI_PORT       GPIOB
#define PIR_DOCI_PIN        GPIO_PIN_4

/* Тайминги в мікросекундах */
#define PIR_TS_US           500     // Start signal (100us~5ms, беремо 500us)
#define PIR_TL_US           6       // Pull down time (4~8us)
#define PIR_TH_US           6       // Pull up time (4~8us)
#define PIR_TB_US           6       // Wait stabilization (4~8us)

#define PIR_TOTAL_BITS      19      // Всього біт у пакеті

/* Стани state machine */
typedef enum {
    PIR_ST_IDLE,                    // Очікування (лінія низька, PIR оновлює дані)
	PIR_ST_WAIT_PIR_LOW,
    PIR_ST_WAIT_PIR_HIGH,           // Чекаємо поки PIR підніме лінію
    PIR_ST_START_HIGH,              // Тримаємо HIGH (tS)
    PIR_ST_CLK_PULL_LOW,            // Тягнемо LOW (tL)
    PIR_ST_CLK_PULL_HIGH,           // Тягнемо HIGH (tH)
    PIR_ST_WAIT_STABILIZE,          // Чекаємо стабілізації біту (tB)
    PIR_ST_SAMPLE_BIT,              // Читаємо біт
    PIR_ST_DONE,                    // Читання завершено
    PIR_ST_ERROR,                   // Помилка (таймаут або невірний заголовок)
} PIR_STATE;

/* Результат читання */
typedef struct {
    int16_t  raw_value;             // 16-бітне знакове значення з HPF
    uint8_t  data_ready;            // 1 = нові дані готові
    uint8_t  error;                 // 1 = помилка читання
} PIR_Data_t;

/* Публічні функції */
void     PIR_Init(TIM_HandleTypeDef *htim_us);
void     PIR_ProcessLoop(void);     // Викликати в main while(1)
PIR_Data_t PIR_GetData(void);


#endif /* PIR_YS312_H_ */
