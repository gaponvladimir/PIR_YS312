#ifndef ADC_MANAGER_H
#define ADC_MANAGER_H

#include <stdint.h>

/**
 * ADC settings for balance sampling frequency and dynamic range
 * Recalculated Timing (The "Safe" Configuration)
 * Apply these settings with 48 MHz SysClk:
 * ADC Prescaler: /4 (fADC=12 MHz).
 * Sampling Time: 47.5 cycles.
 * Conversion Time: 12.5 cycles.
 * Total Time per single conversion: (47.5+12.5)/12000000 = 5μs.
 * Oversampled Channel (128x): 5μs × 128 = 640μs.
 * Full Sequence (4 Channels): 640μs×4=2.56 ms.
 * Result: maximum possible trigger frequency is 390 Hz.
 * For a 10 Hz signal, this is perfect—it's roughly 40× the Nyquist frequency,
 * allowing to perform further digital filtering in software if needed.
 *
 * External Trigger active, you are in what is often called "Triggered Scan Mode":
 * Wait: The ADC sits idle.
 * Trigger: Timer 1 sends a rising edge.
 * Action: The ADC converts Rank 1 (128 times), then Rank 2 (128 times), then Rank 3 (128 times), then Rank 4 (128 times).
 * Transfer: The DMA moves these 4 averaged results to RAM.
 * Finish: The ADC stops and waits for the next Timer 1 pulse.
 * Based on our calculation that the sequence takes 2.56 ms, trigger frequency must be lower than 390 Hz.
 * Setting it to 200 Hz is a safe, professional choice that provides a data point every 5 ms—plenty for a 10 Hz signal.
 *
 * 1. Timer 1 Calculation (for 200 Hz)
 * With a SysClk of 48 MHz, we use the following formula for the Timer Update Frequency: Ftrigger = Fclk / ((PSC+1)×(ARR+1))
 * Recommended Values:
 * Prescaler (PSC): 479
 * Auto-Reload Register (ARR): 499
 *
 * 2. Timer 1 Settings Checklist
 * In CubeMX/STM32CubeIDE, configure Timer 1 as follows:
 * Slave Mode: Disabled
 * Trigger Source: Internal Clock
 * Prescaler: 479
 * Counter Mode: Up
 * Counter Period (ARR): 499
 * Internal Clock Division: No Division
 * Repetition Counter: 0
 * Trigger Output (TRGO) Parameters:
 * Master/Slave Mode: Disable
 * Trigger Event Selection: Update Event (This is what the ADC "sees" via the Timer 1 Trigger Out event setting in your image).
 *
 * Implementation Note
 * In your code, remember to start the Timer and the ADC in DMA mode. The order should be:
 * HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_buffer, 4);
 * HAL_TIM_Base_Start(&htim1);
 */

/** Amount of ADC channels used for sample PIR sensors */
#define ADC_CHANNEL_COUNT	4

/** Size in bytes of the one frame (samples from all 4 channels) */
#define ADC_FRAME_SIZE      (ADC_CHANNEL_COUNT * sizeof(uint16_t))

/** Size of our ring buffer that will store sample frames from all PIR sensors */
#define ADC_RINGBUF_BYTES   1024

/** Amount of sample frames that we can store in our ring buffer */
#define ADC_RINGBUF_FRAMES  (ADC_RINGBUF_BYTES / ADC_FRAME_SIZE)



void adc_manager_init(void);
int adc_sampler_get(uint8_t *ptr_buf, uint32_t amount_of_frames_to_read, uint32_t buf_size);

#endif
