/*
 * signalFiltering.h
 *
 * Adaptive PIR Swing Detector — public interface and configuration.
 *
 * Tuning guide:
 *   1. Run the diagnostic mode in Signal_ProcessLoop (enabled by default).
 *   2. Observe "max" and "min" values printed for each channel while the
 *      area in front of the sensors is empty (no motion).
 *   3. Set CHANNEL_THRESHOLD[i] to roughly 2-3x the idle noise amplitude
 *      for each channel. This ensures the detector ignores background noise
 *      but still catches the much larger signal produced by a passing person.
 *
 * Created on: Feb 19, 2026
 * Author: BBoiko
 */

#ifndef SIGNAL_FILTERING_H
#define SIGNAL_FILTERING_H

#include <stdint.h>
#include <stdbool.h>
#include <stddef.h>

/* Number of ADC channels sampled simultaneously */
#define ADC_CHANNELS        4

/* Size of the raw-sample ring buffer in bytes.
 * Each frame is ADC_CHANNELS * sizeof(uint16_t) = 8 bytes.
 * 1024 bytes holds up to 128 frames (~0.64 s of headroom at 200 Hz). */
#define FILTER_BUF_SIZE     1024

/* Rolling window length in samples.
 * Defines how far back the swing detector looks when searching for a
 * bipolar peak pair. 200 samples = 1 second at 200 Hz.
 * Reducing this value saves RAM (each channel uses WINDOW_SAMPLES * 4 bytes). */
#define WINDOW_SAMPLES      200

/* Number of samples the motion flag stays active after the last confirmed swing.
 * 400 samples = 2 seconds at 200 Hz.
 * Prevents flickering when a person briefly pauses in front of the sensor. */
#define HOLD_SAMPLES        400

/* Number of consecutive quiet samples required before the hold timer starts
 * decaying at an accelerated rate (10x faster).
 * 100 samples = 0.5 seconds at 200 Hz. */
#define STABLE_SAMPLES      100

/* Signal is considered "quiet" when its absolute value is below
 * STABILITY_RATIO * threshold. Used to accelerate hold timer decay. */
#define STABILITY_RATIO     0.5f

/* DC tracking filter coefficient (Exponential Moving Average).
 * Controls how quickly the baseline follows slow sensor drift.
 * 0.01 => time constant ~100 samples (0.5 s) — slow enough to ignore
 * motion, fast enough to track temperature-induced voltage drift. */
#define ALPHA_DC            0.01f

/* Per-channel detection thresholds (in ADC counts after DC removal).
 *
 * How these values were determined (measured with diagnostic output,
 * no motion in front of sensors):
 *   CH0 idle noise amplitude: ~5  counts  => threshold set to 30
 *   CH1 idle noise amplitude: ~5  counts  => threshold set to 30
 *   CH2 idle noise amplitude: ~5  counts  => threshold set to 30
 *   CH3 idle noise amplitude: ~150 counts => threshold set to 250
 *
 * If false triggers occur, increase the threshold for that channel.
 * If the detector misses slow movements, decrease it slightly. */
static const float CHANNEL_THRESHOLD[ADC_CHANNELS] = {30.0f, 30.0f, 30.0f, 250.0f};

/*
 * Per-channel runtime state.
 * One instance is maintained for each ADC channel inside signalFiltering.c.
 */
typedef struct {

    /* Current estimated DC baseline (updated every sample via EMA).
     * Subtracted from raw ADC value to produce a zero-centered signal. */
    float    dc_level;

    /* Set to true after the first real ADC sample has been used to seed
     * dc_level. Prevents a large transient on startup. */
    bool     initialized;

    /* Circular buffer holding the last WINDOW_SAMPLES DC-removed values.
     * The swing detector scans this buffer on every sample. */
    float    window[WINDOW_SAMPLES];
    uint32_t win_idx;      /* Write index (advances modulo WINDOW_SAMPLES)  */
    uint32_t win_filled;   /* How many valid samples are currently in window */

    /* Counts down from HOLD_SAMPLES to 0 after a swing is detected.
     * motion_active is true while this counter is non-zero. */
    uint32_t hold_counter;

    /* Counts consecutive "quiet" samples. When it reaches STABLE_SAMPLES
     * the hold counter is decremented 10x faster. */
    uint32_t stability_counter;

    /* True when hold_counter > 0, i.e. motion was recently detected. */
    bool     motion_active;

} ChannelState;

/* Initialize ring buffer and reset all channel states.
 * Call once at startup, after adc_manager_init(). */
void Signal_Init(void);

/* Write one ADC frame into the ring buffer.
 * Must be called from HAL_ADC_ConvCpltCallback with DMA data. */
void Signal_PushData(uint16_t* data, size_t count);

/* Process all pending frames from the ring buffer.
 * Must be called repeatedly from the main loop (non-blocking). */
void Signal_ProcessLoop(void);

#endif /* SIGNAL_FILTERING_H */
