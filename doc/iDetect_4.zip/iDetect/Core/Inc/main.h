/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
extern UART_HandleTypeDef huart1;
extern RTC_HandleTypeDef hrtc;

/** Device state machine logic enumeration type */
typedef enum {
	ST_PROCESSING_NONE = 0,						/**< Nothing to process */
	ST_CHECK_PACKET,							/**< Check received packet in the circular buffer */
	ST_PROCESS_COMMAND,							/**< Process received command */
	ST_PROCESS_WAIT_ANSWER,						/**< Wait some amount for time for construct answer to host */
	ST_PROCESS_SEND_ANSWER						/**< Send answer for command back to the host */
}DEVICE_STATE;

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

// USB Command buffer size
#define CMD_QUEUE_BUFFER_SIZE   (1024+3+1)
#define read_ADC_Buf_Size 1024
/*-----------------------------------------------------------------------------------*/
// FIRMWARE VERSION EXPRESSED AS XX.YY.ZZ (XX-MAJOR, YY-MINOR, ZZ-REVISION)
#define FIRMWARE_VERSION_MAJOR		'0'			/**< Firmware version major part */
#define FIRMWARE_VERSION_MINOR		'0'			/**< Firmware version minor part */
#define FIRMWARE_VERSION_REVISION	0x01		/**< Firmware version revision part expressed in BCD */

// Serial Number, Firmware Version, Hardware Revision sizes
#define HARDWARE_DELIM_SIZE			(1)			/**< Size of the delimiter between major version number and minor version number and revision */
#define HARDWARE_REV_SIZE			(2 + 1)		/**< Hardware revision size in bytes expressed as ASCII two bytes Major and Minor  + zero termination */
#define FIRMWARE_VER_SIZE			(3 + 2)		/**< Firmware version expressed as XX.YY.ZZ (XX - Major, YY - Minor, ZZ - Revision) + zero termination */
#define SERIAL_NUMBER_SIZE			(7 + 1)		/**< Size of the serial number string including zero termination without any preceding prefixes */

extern TIM_HandleTypeDef htim1;
extern DMA_HandleTypeDef hdma_adc1;
extern ADC_HandleTypeDef hadc1;
/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
int usb_callback_put_command_into_process_queue(uint8_t* Buf, uint32_t Len);

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define LED_Pin GPIO_PIN_6
#define LED_GPIO_Port GPIOC

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
