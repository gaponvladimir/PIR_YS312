#ifndef _HELPER_H_
#define _HELPER_H_

// Firmware update FLASH addresses
//#define FW_UPDATE_FLASH_START_ADDRESS		(0x0)
//#define FW_UPDATE_FLASH_END_ADDRESS		(FW_UPDATE_FLASH_START_ADDRESS + 0x100000 - 1)

#define GMT_ADD	0   // current timezone shift

/** Maximum value of the currently available hardware revision major part */
#define HARDWARE_REVISION_MAJOR_MAX         '0'
/** Maximum value of the currently available hardware revision minor part */
#define HARDWARE_REVISION_MINOR_MAX         '1'

// get difference between 2 tick time values
uint32_t GetTickDiff(uint32_t tickStart, uint32_t tickEnd);

// Assemble integer from bytes (big endian version)
unsigned int integer_from_bytes_big_endian(unsigned char bytes[4]);

// Assemble integer from bytes (little endian version)
unsigned int integer_from_bytes_little_endian(unsigned char bytes[4]);

// Assemble short from bytes (little endian version)
unsigned short short_from_bytes_little_endian(unsigned char bytes[2]);

// Assemble short from bytes (big endian version)
unsigned short short_from_bytes_big_endian(unsigned char bytes[2]);

// Create byte array in little endian format from short
void short_to_bytes_little_endian(unsigned short value, unsigned char *data);

// Create byte array in big endian format from short
void short_to_bytes_big_endian(unsigned short value, unsigned char *data);

// Create byte array in big endian format from integer
void integer_to_bytes_big_endian(unsigned int value, unsigned char *data);

// Create byte array in little endian format from integer
void integer_to_bytes_little_endian(unsigned int value, unsigned char *data);

// Convert supplied string to the integer value
int conv_string_to_int(const char* str, int* result, int base);

// Calculates length of the supplied string
size_t str_len(const char *str);

// Converts string to integer
long str_tol(const char *nptr, char **endptr, register int base);

// Search substring in string with specified limit length
char* strnstr(const char *s1, const char *s2, size_t n);

// Fill memory by the specified character
void *mem_set(void *s, int c, size_t n);

// Copy one array of data to another with specified length
void *mem_cpy(void *dest, const void *src, size_t len);

int Get_Hardware_Revision(char *hv_buf, unsigned int hv_buf_size);
unsigned char Get_Hardware_Revision_as_HEX(void);
int Get_Firmware_Version(char *fv_buf, unsigned int fv_buf_size);
int Get_Serial(char *serial_buf, unsigned int serial_buf_size);
int Set_System_Time(char *time_data);
int Get_System_Time(unsigned int *tmc);

#endif // _HELPER_H_
