#include "main.h"
#include "debug.h"
#include <errno.h>
#include <limits.h>
#include <ctype.h>
//#include "dwt_delay.h"
#include "helper.h"
//#include "otp.h"
#include "atomic.h"
#include "time.h"
#include "main.h"

/*-----------------------------------------------------------------------------------*/
/** Convert array of bytes supplied in big endian format to integer
 *
 * \param bytes Pointer to the array of 4 bytes MSB placed first
 * \return Converted integer value
 */
unsigned int integer_from_bytes_big_endian(unsigned char bytes[4])
{
	unsigned int ret_val;
  // MSB:LSB -> (unsigned int)((data[0] << 24) | (data[1] << 16) | (data[2] << 8) | data[3]);
	ret_val = (uint32_t) (bytes[0] << 24) | (bytes[1] << 16) | (bytes[2] << 8) | bytes[3];

	return ret_val;
}

/*-----------------------------------------------------------------------------------*/
/** Convert array of bytes supplied in little endian format to integer
 *
 * \param bytes Pointer to the array of 4 bytes LSB placed first
 * \return Converted integer value
 */
unsigned int integer_from_bytes_little_endian(unsigned char bytes[4])
{
	unsigned int ret_val;
  // LSB:MSB -> (unsigned int)((data[3] << 24) | (data[2] << 16) | (data[1] << 8) | data[0]);
	ret_val = (uint32_t) (bytes[3] << 24) | (bytes[2] << 16) | (bytes[1] << 8) | bytes[0];

	return ret_val;
}

/*-----------------------------------------------------------------------------------*/
/** Convert array of bytes supplied in little endian format to 16-bit short value
 *
 * \param bytes Pointer to the array of 2 bytes LSB placed first
 * \return Converted short value
 */
unsigned short short_from_bytes_little_endian(unsigned char bytes[2])
{
	unsigned short ret_val;

	ret_val = (bytes[1] << 8) | bytes[0];

	return ret_val;
}

/*-----------------------------------------------------------------------------------*/
/** Convert array of bytes supplied in big endian format to 16-bit short value
 *
 * \param bytes Pointer to the array of 2 bytes MSB placed first
 * \return Converted short value
 */
unsigned short short_from_bytes_big_endian(unsigned char bytes[2])
{
	unsigned short ret_val;

	ret_val = (bytes[0] << 8) | bytes[1];

	return ret_val;
}

/*-----------------------------------------------------------------------------------*/
/** Convert short value into the array of bytes in little endian format
 *
 * \param value Short value that must be converted into the array of bytes
 * \param bytes Pointer to the array of 2 bytes LSB placed first
 * \return None
 */
void short_to_bytes_little_endian(unsigned short value, unsigned char *data)
{
  if (data == 0) {
    return;
  }

  data[0] = (unsigned char) (value);
  data[1] = (unsigned char) (value >> 8);
}

/*-----------------------------------------------------------------------------------*/
/** In-home implementation of the "strlen" function
 *
 * \param	str	Pointer to the string which length calculated
 * \return		Length of the supplied string
 */
size_t str_len(const char *str)
{
    const char *start = str;

    // Untill we found '\0' stay in loop
    while (*str != '\0') {
    	// increment pointer
        str++;
    }

    // Return difference between the address
    return str - start;
}

/*-----------------------------------------------------------------------------------*/
/* Find the first substring in a length-limited string
 *
 * \param s1 The string in which to search
 * \param s2 The string to search
 * \param n Length of the string  s1
 * \return pointer to the first occurrence or NULL if not found
 */
char* strnstr(const char *s1, const char *s2, size_t n)
{
	// simplistic algorithm with O(n2) worst case
	size_t i, len;
	char c = *s2;

	if (c == '\0') {
		return (char*)s1;
	}

	for (len = str_len(s2); len <= n; n--, s1++) {
		if (*s1 == c) {
			for (i = 1;; i++) {
				if (i == len) {
					return (char*)s1;
				}
				if (s1[i] != s2[i]) {
					break;
				}
			}
		}
	}
	return NULL;
}

/*-----------------------------------------------------------------------------------*/
/** Convert short value into the array of bytes in big endian format
 *
 * \param value Short value that must be converted into the array of bytes
 * \param bytes Pointer to the array of 2 bytes MSB placed first
 * \return None
 */
void short_to_bytes_big_endian(unsigned short value, unsigned char *data)
{
  if (data == 0) {
    return;
  }

  data[1] = (unsigned char) (value);
  data[0] = (unsigned char) (value >> 8);
}


/*-----------------------------------------------------------------------------------*/
/** Convert integer value into the array of bytes in big endian format
 *
 * \param value Integer value that must be converted into the array of bytes
 * \param bytes Pointer to the array of 4 bytes MSB placed first
 * \return None
 */
void integer_to_bytes_big_endian(unsigned int value, unsigned char *data)
{
  if (data == 0) {
    return;
  }

  data[0] = (unsigned char) (value >> 24);
  data[1] = (unsigned char) (value >> 16);
  data[2] = (unsigned char) (value >> 8);
  data[3] = (unsigned char) (value);
}

/*-----------------------------------------------------------------------------------*/
/** Convert integer value into the array of bytes in little endian format
 *
 * \param value Integer value that must be converted into the array of bytes
 * \param bytes Pointer to the array of 4 bytes LSB placed first
 * \return None
 */
void integer_to_bytes_little_endian(unsigned int value, unsigned char *data)
{
  if (data == 0) {
    return;
  }

  data[0] = (unsigned char) (value);
  data[1] = (unsigned char) (value >> 8);
  data[2] = (unsigned char) (value >> 16);
  data[3] = (unsigned char) (value >> 24);
}

/*
 * Convert a string to a long integer.
 *
 * Ignores `locale' stuff.  Assumes that the upper and lower case
 * alphabets and digits are each contiguous.
 */
long str_tol(const char *nptr, char **endptr, register int base)
{
	register const char *s = nptr;
	register unsigned long acc;
	register int c;
	register unsigned long cutoff;
	register int neg = 0, any, cutlim;

	/*
	 * Skip white space and pick up leading +/- sign if any.
	 * If base is 0, allow 0x for hex and 0 for octal, else
	 * assume decimal; if base is already 16, allow 0x.
	 */
	do {
		c = *s++;
	} while (isspace(c));

	if (c == '-') {
		neg = 1;
		c = *s++;
	} else if (c == '+')
		c = *s++;
	if ((base == 0 || base == 16) &&
	    c == '0' && (*s == 'x' || *s == 'X')) {
		c = s[1];
		s += 2;
		base = 16;
	}
	if (base == 0)
		base = c == '0' ? 8 : 10;

	/*
	 * Compute the cutoff value between legal numbers and illegal
	 * numbers.  That is the largest legal value, divided by the
	 * base.  An input number that is greater than this value, if
	 * followed by a legal input character, is too big.  One that
	 * is equal to this value may be valid or not; the limit
	 * between valid and invalid numbers is then based on the last
	 * digit.  For instance, if the range for longs is
	 * [-2147483648..2147483647] and the input base is 10,
	 * cutoff will be set to 214748364 and cutlim to either
	 * 7 (neg==0) or 8 (neg==1), meaning that if we have accumulated
	 * a value > 214748364, or equal but the next digit is > 7 (or 8),
	 * the number is too big, and we will return a range error.
	 *
	 * Set any if any `digits' consumed; make it negative to indicate
	 * overflow.
	 */
	cutoff = neg ? -(unsigned long)LONG_MIN : LONG_MAX;
	cutlim = cutoff % (unsigned long)base;
	cutoff /= (unsigned long)base;
	for (acc = 0, any = 0;; c = *s++) {
		if (isdigit(c))
			c -= '0';
		else if (isalpha(c))
			c -= isupper(c) ? 'A' - 10 : 'a' - 10;
		else
			break;
		if (c >= base)
			break;
		if (any < 0 || acc > cutoff || (acc == cutoff && c > cutlim))
			any = -1;
		else {
			any = 1;
			acc *= base;
			acc += c;
		}
	}
	if (any < 0) {
		acc = neg ? LONG_MIN : LONG_MAX;
		errno = ERANGE;
	} else if (neg)
		acc = -acc;
	if (endptr != 0)
		*endptr = (char *) (any ? s - 1 : nptr);
	return (acc);
}

/*-----------------------------------------------------------------------------------*/
/** Convert supplied string to integer value
 *
 * Function tries to convert supplied string to binary value.
 * Base specifies radix: 10 - decimal, 16 - hex decimal.
 *
 * \param[in]	str			String of hex-decimal characters that must be converted into the binary representation.
 * \param[out]	result		Pointer to the buffer where to put converted bytes.
 * \param[in]	base		Numerical base (radix) that determines the valid characters and their interpretation.
 * \return					'0' - if string successfully converted, '-1' otherwise.
 */
int conv_string_to_int(const char* str, int* result, int base)
{
	char* end;

	// Check supplied arguments for validity
	if (result == 0 || str == 0) {
		return (-1);
	}

	// Reset errno value
	errno = 0;

	// Convert string to integer with supplied base
	*result = str_tol(str, &end, base);

	if ((*end != '\0') && (errno != 0)) {
		return (-1);
	}

	return 0;
}

/*-----------------------------------------------------------------------------------*/
/** Fill specified memory with character value defined as parameter
 *
 * \param	s	Pointer to the array that must be filled
 * \param	c	Character value that is used as filled parameter
 * \param	n	Array length
 * \return		Pointer to the supplied string
 */
void *mem_set(void *s, int c, size_t n)
{
	// Cast to unsigned char* to perform byte-wise operations
    unsigned char *ptr = (unsigned char*)s;

    // Assign the value (converted to unsigned char) to each byte
    while (n-- > 0) {
        *ptr++ = (unsigned char)c;
    }

    // Return the original pointer
    return s;
}

/*-----------------------------------------------------------------------------------*/
/** Reload one array to another with specified length
 *
 * \param	dest	Pointer to the destination array
 * \param	src		Pointer to the source array
 * \param	len		Length of data to copy
 * \return			Pointer to the destination array
 */
void *mem_cpy(void *dest, const void *src, size_t len)
{
    char *d = dest;
    const char *s = src;

    while (len--) {
        *d++ = *s++;
    }

    return dest;
}

/*-----------------------------------------------------------------------------------*/
/** Get time difference between two events
 *
 * \param	tickStart		Event start time expressed in ticks
 * \param	tickEnd			Event stop time expressed in ticks
 * \return 						Difference in ms between two events
 */
/*__INLINE*/ uint32_t GetTickDiff(uint32_t tickStart, uint32_t tickEnd)
{
    return (tickEnd - tickStart);
}

/*-----------------------------------------------------------------------------------*/
/** Get hardware revision from OTP memory
 *
 * First supplied buffer filed with zeros. Next function tries to check
 * if size of supplied buffer is enough for storing hardware revision and
 * delimiter function reloads major & minor and revision versions of the hardware version.
 * If hardware revision does not exist in the specified OTP memory location, supplied
 * buffer will contains only terminated zeros.
 *
 * \param	hv_buf		Pointer to the buffer where to store null terminated hardware version expressed as XX.YY
 * \param	hv_buf_size	Size of the supplied buffer
 * \return				Null terminated string XX.YY (where XX is a major hardware version and YY is a minor one)
 *						or zero if information can't be extracted from OTP memory
 */
int Get_Hardware_Revision(char *hv_buf, unsigned int hv_buf_size)
{
	/** ToDo: Add functionality for read ADC and construct hardware version using voltage on dedicated pin */
	const char *HardwareVersion = "0.1";

	// Check supplied buffer pointer for validity
	if (hv_buf == 0) {
		return (-1);
	}

	// Fill supplied buffer with zeroes
	mem_set(hv_buf, 0x0, hv_buf_size);

	// Check if hardware revision buffer is enough to store hardware revision + delimiter
	if ((HARDWARE_REV_SIZE + HARDWARE_DELIM_SIZE) > hv_buf_size) {
		// Don't fill any hardware revision into supplied buffer -> go out
		return (-1);
	}


	// Copy hardware revision plus '\0' at the end
	mem_cpy(hv_buf, HardwareVersion, str_len(HardwareVersion) + 1);

	/*
	char hv_otp_buf[OTP_BYTES_IN_BLOCK];

	// Clear local buffer used for hardware revision
	mem_set(hv_otp_buf, 0x0, OTP_BYTES_IN_BLOCK);
	// Clear supplied buffer for hardware version
	mem_set(hv_buf, 0x0, hv_buf_size);
	// Check if hardware revision buffer is enough to store hardware revision + delimiter
	if ((HARDWARE_REV_SIZE + HARDWARE_DELIM_SIZE) > hv_buf_size) {
		// Don't fill any hardware revision into supplied buffer -> go out
		return (-1);
	}

	// Read hardware version to the local buffer
	if (HAL_OTP_Read_String(OTP_BLOCK_NUMBER_HW, 0, hv_otp_buf) != HAL_OK) {
		return (-1);
	}

	// Reload major hardware revision part
	if (hv_otp_buf[0] == 0) {
		return (-1);
	}
	hv_buf[0] = hv_otp_buf[0];

	// Insert delimiter
	hv_buf[1] = '.';

	// Reload minor hardware revision part
	if (hv_otp_buf[1] == 0) {
		return (-1);
	}
	hv_buf[2] = hv_otp_buf[1];
	*/
	return (0);
}

/*-----------------------------------------------------------------------------------*/
/** Get hardware revision from OTP memory as HEX
 *
 * Function convert board hardware revision expressed as text value into the hex equivalent.
 * Returned value expressed as hex value where four high bits of the nibble is major part of
 * hardware revision and four low bits of the nibble is a minor part of the revision.
 * For read revision from OTP memory \sa Get_Hardware_Revision function is used.
 * If the revision is not programmed in the OTP memory the maximum revision value is returned.
 * \sa HARDWARE_REVISION_MAJOR_MAX and \sa HARDWARE_REVISION_MINOR_MAX definitions are designate
 * current hardware revision max value. Max value is used for new boards for test firmware because
 * the OTP value is not set.
 *
 * \return Firmware revision expressed as hex
 */
unsigned char Get_Hardware_Revision_as_HEX(void)
{
    int status;
    char hardware_revision[4];
    unsigned char rev_as_hex;

    status = Get_Hardware_Revision(hardware_revision, sizeof(hardware_revision));
    if (status < 0 || hardware_revision[0] < 0x30 || hardware_revision[0] > 0x39 || hardware_revision[2] < 0x30 || hardware_revision[2] > 0x39) {
        hardware_revision[0] = HARDWARE_REVISION_MAJOR_MAX;
        hardware_revision[1] = '.';
        hardware_revision[2] = HARDWARE_REVISION_MINOR_MAX;
    }

    // Remove ASCII notation from major part
    rev_as_hex = hardware_revision[0] - 0x30;
    // Move major part to the high part of byte
    rev_as_hex <<= 4;
    // Remove ASCII notation from minor part and add it to the low part of the revision HEX representation
    rev_as_hex |= (hardware_revision[2] - 0x30);

    DBG(DBG_DEBUG, "Hardware revision: v%02X\n", rev_as_hex);

    return rev_as_hex;
}

/*-----------------------------------------------------------------------------------*/
/** Get firmware version
 *
 * Function construct firmware version expressed as XX.YY.ZZ based on values stored
 * in "main.h" file. At the end of the constructed string "\0" delimiter is added.
 * If size of the supplied buffer is less then required for construct firmware version
 * string function return (-1) value.
 *
 * \param fv_buf			Pointer to the buffer where assemble firmware version string
 * \param fv_buf_size	    Size of the firmware version buffer
 * \return					"0" - if firmware version string expressed as XX.YY.ZZ successfully constructed,
 *							"-1" - otherwise.
 */
int Get_Firmware_Version(char *fv_buf, unsigned int fv_buf_size)
{

	// Check if firmware version buffer is enough to store firmware version + two delimiters
	if ((FIRMWARE_VER_SIZE + HARDWARE_DELIM_SIZE * 2) > fv_buf_size) {
		// Don't fill any hardware revision into supplied buffer -> go out
		return (-1);
	}

	fv_buf[0] = FIRMWARE_VERSION_MAJOR;
	fv_buf[1] = '.';
	fv_buf[2] = FIRMWARE_VERSION_MINOR;
	fv_buf[3] = '.';
	// Convert Revision from BCD to ASCII
	fv_buf[4] = (FIRMWARE_VERSION_REVISION >> 4) + 0x30;
	fv_buf[5] = (FIRMWARE_VERSION_REVISION & 0x0F) + 0x30;
	fv_buf[6] = '\0';

	return (0);
}

/*-----------------------------------------------------------------------------------*/
/** Get serial number from OTP memory
 *
 * First supplied buffer filed with zeros. Next function tries to check
 * if size of supplied buffer is enough for storing prefix and serial number
 * function reloads first prefix and after that serial till zero termination.
 * If serial dose not exist in the specified OTP memory location, supplied
 * buffer will contains only terminated zeros.
 *
 * \param	serial_buf		Pointer to the buffer where to store serial number
 * \param	serial_buf_size	Size of the serial number buffer
 * \return					Amount of character in serial - if serial number
 *							reloaded to the supplied buffer, "-1" - otherwise
 */
int Get_Serial(char *serial_buf, unsigned int serial_buf_size)
{
	/** ToDo: Add functionality for read serial number from OTP or convert UID to serial number */
	const char dev_serial[SERIAL_NUMBER_SIZE] = "0000001";
	int serial_number_length = 0;

	// Check if supplied buffer is valid
	if (serial_buf == 0) {
		return (-1);
	}

	// Clear supplied buffer
	mem_set(serial_buf, 0x0, serial_buf_size);

	// Get serial number length
	serial_number_length = str_len(dev_serial);

	// If supplied buffer size is equal or greater then our serial number
	if (serial_buf_size >= (serial_number_length + 1)) {
		// Reload serial number to the supplied buffer
		mem_cpy(serial_buf, dev_serial, serial_number_length);
		return serial_number_length;
	}
	else {
		return (-1);
	}

/*	char sn_otp_buf[OTP_BYTES_IN_BLOCK];

	// Clear local buffer used for serial number
	mem_set(sn_otp_buf, 0x0, OTP_BYTES_IN_BLOCK);
	// Clear supplied buffer for serial number
	mem_set(serial_buf, 0x0, serial_buf_size);
	// If serial number prefix must be displayed
#if SUPPORT_SERIAL_NUMBER_PREFIX
	// Check if serial buffer is enough to store serial number + prefix
	if ((SERIAL_NUMBER_SIZE + sizeof(SERIAL_NUMBER_PREFIX)) > serial_buf_size) {
		// Don't fill any serial into supplied buffer -> go out
		return (-1);
	}
// If serial number prefix not displayed
#else
	// Check if serial buffer is enough to store serial number
	if (SERIAL_NUMBER_SIZE > serial_buf_size) {
		// Don't fill any serial into supplied buffer -> go out
		return (-1);
	}
#endif

	// Read serial number to the local serial number buffer
	if (HAL_OTP_Read_String(OTP_BLOCK_NUMBER_SN, 0, sn_otp_buf) != HAL_OK) {
		return (-1);
	}

#if SUPPORT_SERIAL_NUMBER_PREFIX
	// Copy prefix to the supplied serial buffer
	str_cpy(serial_buf, SERIAL_NUMBER_PREFIX);
	// Copy serial number to the suppled serial buffer
	strncpy(&serial_buf[sizeof(SERIAL_NUMBER_PREFIX) - 1], sn_otp_buf, SERIAL_NUMBER_SIZE - 1);
#else
	// Copy serial number to the supplied serial buffer
	mem_cpy(serial_buf, sn_otp_buf, SERIAL_NUMBER_SIZE - 1);
#endif

	return strlen(serial_buf);
*/
}

/*-----------------------------------------------------------------------------------*/
/** Write value to the CPU environment
 * First in the buffer places a name of variable, terminated by 0 and then a
 * value of the variable, also terminated by 0. If the buffer contents only
 * one string terminated by 0 - it means the variable must be erased in environment.
 *
 * \param env_buf Pointer to the buffer that contains the variable and it's value
 * \param env_buf_len Length of supplied buffer
 * \return 	Status of operation:
 *          "0" - Environment variable Name/Value successfully written
 *          "-1" - Environment variable Name is wrong
 *          "-2" - Environment variable Value is wrong
 *          "-3" - error detected during environment write
 */
/*
int Write_CPU_Environment(char *env_buf, unsigned int env_buf_len)
{
	unsigned int name_len, value_len;
	char *name = 0, *value = 0;
	ENV_STATUS e_state;
	int cntr = 10;

	// set the name pointer
	name = env_buf;
	name_len = strlen(name) + 1;

	// if wrong name length - signaling error
	if ((name_len < 2) || (name_len > env_buf_len)) {
		return (-1);
	}

	// if only name in the input data - delete the environment variable , else - write a new value
	if(name_len == env_buf_len){
		value = 0;
	}
	else {
		value = name + name_len;
		value_len = strlen(value) + 1;

		// if the wrong value length - error
		if (value_len > (env_buf_len - name_len)){
			return (-2);
		}
	}

  // Try to put variable to environment, if failed - return error
  // wait for a while if environment is busy
  do {
		e_state = env_put(name, value);
		// If environment is busy
		if (e_state == ENVIRONMENT_BUSY) {
			cntr--;
			// Delay for 1ms (try to wait for external process (maybe in interrupt) free environment)
			HAL_Delay(1);
		}
	} while ((e_state == ENVIRONMENT_BUSY) && (cntr != 0));

	if (e_state != ENVIRONMENT_OK) {
		return (-3);
	}

	return 0;
}
*/

/*-----------------------------------------------------------------------------------*/
/** Read value from CPU environment
 *
 * Function reads a variable from CPU environment by name
 *
 * \param var_name Pointer to the string variable name
 * \param value_buf Pointer to a buffer for the variable value
 * \param value_buf_size Size of the value buffer
 * \return					environment variable length plus one if environment variable read successfully
 *							    "-1" - supplied variable name length is wrong
 *                  "-2" - environment is busy or error during reading detected
 *                  "-3" - supplied buffer length is not enough for store variable
 */
/*
int Read_CPU_Environment(char *var_name, char *value_buf, unsigned int value_buf_size)
{
	unsigned int len;
	char *value = 0;
	ENV_STATUS e_state;
	int cntr = 10;

	// get length of the variable name
	len = strlen(var_name);

	// if the name length is wrong - return an error
	if(len < 2 || len >= 256){
		return (-1);
	}

	// read the variable in an environment database
	do {
		e_state = env_get((char*)var_name, &value);
		// If environment is busy
		if (e_state == ENVIRONMENT_BUSY) {
			cntr--;
			// Delay for 1ms (try to wait for external process (maybe in interrupt) free environment)
			DWT_Delay_ms(1);
		}
	} while ((e_state == ENVIRONMENT_BUSY) && (cntr != 0));

	// if variable does not exists - return an error
	if(e_state != ENVIRONMENT_OK){
		return (-2);
	}

	// get length  of the value and check it for errors, if the length of the value more than size of incoming buffer - return an error
	len = strlen(value) + 1;
	if(len > value_buf_size){
		return (-3);
	}

	// save value to value buffer
	memcpy(value_buf, value, len);

	return len;
}
*/

/*-----------------------------------------------------------------------------------*/
/** Set system time
 *
 * Function set time to system clock
 *
 * \param  time_data        time data in raw format
 * \return					"0" - OK
 *							otherwise - error
 */

int Set_System_Time(char *time_data)
{
	time_t rawtime = 0;
	struct tm *setTime;
    HAL_StatusTypeDef res;
    RTC_TimeTypeDef time;
    RTC_DateTypeDef date;

	// convert time to int from data buffer: (uint32_t)((time_data[0] << 24) | (time_data[1] << 16) | (time_data[2] << 8) | (time_data[3]));
	rawtime = integer_from_bytes_big_endian((unsigned char *)time_data);

	// fill time structure
	setTime = localtime(&rawtime);
	setTime->tm_hour += GMT_ADD;

    // Fill all unused field in tm structure and check if time is valid
	if (mktime(setTime) < 0) {
		return (-1);
	}

	// clear time and date structures
	mem_set(&time, 0, sizeof(time));
    mem_set(&date, 0, sizeof(date));

    // In RTC_DateStruct Sunday is 0x07 in tm structure Sunday is 0x0
	int weekDay = (setTime->tm_wday == 0) ? 7 : setTime->tm_wday;
	// In time.h years are defined since 1900, in chip years are defined since 2000
	int year = setTime->tm_year + 1900 - 2000;

    date.WeekDay = weekDay;
    date.Year = year;
    date.Month = setTime->tm_mon + 1;
    date.Date = setTime->tm_mday;

    res = HAL_RTC_SetDate(&hrtc, &date, RTC_FORMAT_BIN);
    if(res != HAL_OK) {
        DBG(DBG_DEBUG,"HAL_RTC_SetDate failed: %d\n", res);
        return -2;
    }

    time.Hours = setTime->tm_hour;
    time.Minutes = setTime->tm_min;
    time.Seconds = setTime->tm_sec;

    res = HAL_RTC_SetTime(&hrtc, &time, RTC_FORMAT_BIN);
    if(res != HAL_OK) {
        DBG(DBG_DEBUG,"HAL_RTC_SetTime failed: %d\n", res);
        return -3;
    }

	return 0;
}

/*-----------------------------------------------------------------------------------*/
/*
// display system date and time
int Display_System_Time(void)
{
    RTC_TimeTypeDef time;
    RTC_DateTypeDef date;

    if(HAL_RTC_GetTime(&hrtc, &time, RTC_FORMAT_BIN) == HAL_OK) {
        APP_DEBUG(DBG_TRACE, "HAL_RTC_GetTime: %.2d:%.2d:%.2d\n", time.Hours, time.Minutes, time.Seconds);
    } else {
        APP_DEBUG(DBG_TRACE, "HAL_RTC_GetTime failed \n");
    }

    if(HAL_RTC_GetDate(&hrtc, &date, RTC_FORMAT_BIN)== HAL_OK) {
        APP_DEBUG(DBG_TRACE, "HAL_RTC_GetTime: %.2d.%.2d.%.2d day %d\n", date.Date, date.Month, date.Year+1980, date.WeekDay);
    } else {
        APP_DEBUG(DBG_TRACE, "HAL_RTC_GetDate failed: \n");
    }

    return 0;
}
*/

/** Get device system time
 *
 * Function get time of system clock
 *
 * \param  tmc       		 buffer for get time
 * \return					"0" - OK
 *							otherwise - error
 */
int Get_System_Time(unsigned int *tmc)
{
    RTC_TimeTypeDef sTime;
    RTC_DateTypeDef sDate;
    struct tm tm_time;
    time_t timestamp;

    /* Read time */
    if (HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN) != HAL_OK)
        return -1;


    if (HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN) != HAL_OK)
        return -2;

    /* Filling struct tm */
    mem_set(&tm_time, 0, sizeof(tm_time));

    tm_time.tm_sec  = sTime.Seconds;
    tm_time.tm_min  = sTime.Minutes;
    tm_time.tm_hour = sTime.Hours;

    tm_time.tm_mday = sDate.Date;
    tm_time.tm_mon  = sDate.Month - 1;
    tm_time.tm_year = sDate.Year + 100;
    tm_time.tm_isdst = 0;

    /* Convert to Unix timestamp */
    timestamp = mktime(&tm_time);
    if (timestamp < 0)
        return -3;

    *tmc = (unsigned int)timestamp;
    return 0;
}

/*int Get_System_Time(unsigned int *tmc)
{
	time_t rawtime;
	struct tm *timeinfo;
	time_t timestamp;
	// Get current time
	time(&rawtime);
	timeinfo = localtime(&rawtime);
	// Convert it to the timestamp value
	timestamp = mktime(timeinfo);
	*tmc = timestamp;

	//printf("Time in seconds: %u\n", current);
	return (0);
}*/

