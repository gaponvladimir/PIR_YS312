/*
 * signalFiltering.c
 *
 * Adaptive PIR Swing Detector
 *
 * Detects human motion by analyzing PIR sensor signals using a bipolar
 * swing detection algorithm. Motion is confirmed only when the signal
 * crosses both a positive AND negative threshold within a rolling time
 * window (1 second). This approach rejects single-sided noise spikes
 * and only responds to the characteristic wave pattern caused by a
 * person passing through the sensor's Fresnel lens zones.
 *
 * Created on: Feb 19, 2026
 * Author: BBoiko
 */

#include "signalFiltering.h"
#include "lwrb.h"
#include "debug.h"
#include "main.h"

/* Ring buffer for raw ADC samples coming from DMA interrupt */
static lwrb_t       raw_data_ringbuf;
static uint8_t      raw_data_storage[FILTER_BUF_SIZE];

/* Per-channel filter and detector state */
static ChannelState channels[ADC_CHANNELS];

/*---------------------------------------------------------------------------
 * Signal_Init
 *
 * Must be called once before the main loop starts (after adc_manager_init).
 * Initializes the ring buffer and resets all channel states to defaults.
 *--------------------------------------------------------------------------*/
void Signal_Init(void)
{
    lwrb_init(&raw_data_ringbuf, raw_data_storage, sizeof(raw_data_storage));

    for (int i = 0; i < ADC_CHANNELS; i++) {
        /* Start DC level at mid-scale for 12-bit ADC (0-4095) */
        channels[i].dc_level    = 2048.0f;
        channels[i].initialized = false;

        /* Clear the rolling window buffer */
        for (int j = 0; j < WINDOW_SAMPLES; j++)
            channels[i].window[j] = 0.0f;

        channels[i].win_idx           = 0;
        channels[i].win_filled        = 0;
        channels[i].hold_counter      = 0;
        channels[i].stability_counter = 0;
        channels[i].motion_active     = false;
    }

    DBG(DBG_TRACE, "Signal_Init OK, thr=[%d,%d,%d,%d]",
        (int)CHANNEL_THRESHOLD[0], (int)CHANNEL_THRESHOLD[1],
        (int)CHANNEL_THRESHOLD[2], (int)CHANNEL_THRESHOLD[3]);
}

/*---------------------------------------------------------------------------
 * Signal_PushData
 *
 * Called from DMA complete interrupt (HAL_ADC_ConvCpltCallback).
 * Writes one frame of 4-channel ADC samples into the ring buffer.
 * If the buffer is full, the oldest frame is discarded to make room.
 *
 * @param data   Pointer to array of ADC values (one per channel)
 * @param count  Number of channels (= ADC_CHANNELS = 4)
 *--------------------------------------------------------------------------*/
void Signal_PushData(uint16_t* data, size_t count)
{
    size_t needed = count * sizeof(uint16_t);

    /* Drop oldest frame if there is no space for the new one */
    if (lwrb_get_free(&raw_data_ringbuf) < needed)
        lwrb_skip(&raw_data_ringbuf, needed);

    lwrb_write(&raw_data_ringbuf, data, needed);
}

/*---------------------------------------------------------------------------
 * Signal_ProcessLoop
 *
 * Called continuously from the main loop (not from interrupt).
 * Reads all available frames from the ring buffer and runs the
 * swing detection algorithm on each channel.
 *
 * Algorithm per channel, per sample:
 *   1. DC removal  — slow EMA tracks the baseline drift
 *   2. Rolling window — stores last WINDOW_SAMPLES centered values
 *   3. Swing check — motion = signal crossed +threshold AND -threshold
 *                    within the window (bipolar swing = human signature)
 *   4. Hold timer  — keeps motion flag active for HOLD_SAMPLES after
 *                    last confirmed swing
 *   5. Stability   — accelerates hold decay if signal has been quiet
 *                    for STABLE_SAMPLES consecutive samples
 *   6. LED output  — LED on if any channel reports active motion
 *--------------------------------------------------------------------------*/
void Signal_ProcessLoop(void)
{
    uint16_t sample_batch[ADC_CHANNELS];
    const size_t frame_size = sizeof(sample_batch);

    /* Diagnostic variables — print peak amplitudes once per second */
    static uint32_t diag_counter = 0;
    static float    max_c[ADC_CHANNELS] = {0};
    static float    min_c[ADC_CHANNELS] = {0};

    while (lwrb_get_full(&raw_data_ringbuf) >= frame_size)
    {
        lwrb_read(&raw_data_ringbuf, sample_batch, frame_size);

        bool any_motion = false;

        for (int i = 0; i < ADC_CHANNELS; i++)
        {
            float raw = (float)sample_batch[i];

            /* On first sample, seed the DC level with the real ADC value
             * instead of the default 2048, to avoid a large initial transient */
            if (!channels[i].initialized) {
                channels[i].dc_level    = raw;
                channels[i].initialized = true;
                continue;
            }

            /* --- Step 1: DC removal (Exponential Moving Average) ---
             * dc_level tracks the slow baseline drift of the PIR sensor.
             * ALPHA_DC = 0.01 means the tracker has a time constant of
             * ~100 samples (0.5 s at 200 Hz) — slow enough to ignore motion,
             * fast enough to follow temperature-induced drift. */
            channels[i].dc_level = (1.0f - ALPHA_DC) * channels[i].dc_level
                                  + ALPHA_DC * raw;
            float centered     = raw - channels[i].dc_level;
            float abs_centered = (centered < 0.0f) ? -centered : centered;

            /* Fixed detection threshold for this channel (see signalFiltering.h).
             * Thresholds are tuned per channel based on measured noise floor. */
            float threshold = CHANNEL_THRESHOLD[i];

            /* --- Step 2: Rolling window ---
             * Store the DC-removed sample in a circular buffer.
             * This gives the algorithm "memory" of the last 1 second. */
            channels[i].window[channels[i].win_idx] = centered;
            channels[i].win_idx = (channels[i].win_idx + 1) % WINDOW_SAMPLES;
            if (channels[i].win_filled < WINDOW_SAMPLES)
                channels[i].win_filled++;

            /* --- Step 3: Bipolar swing check ---
             * Scan the entire window for both a positive and a negative peak.
             * A single spike in one direction is ignored (noise/interference).
             * Only a full bipolar swing — matching the physical PIR response
             * when a person crosses two adjacent Fresnel zones — triggers motion. */
            bool has_high = false;
            bool has_low  = false;
            for (uint32_t j = 0; j < channels[i].win_filled; j++) {
                if (channels[i].window[j] >  threshold) has_high = true;
                if (channels[i].window[j] < -threshold) has_low  = true;
                if (has_high && has_low) break; /* early exit once both found */
            }

            /* --- Step 4: Motion detection and hold timer ---
             * When a full swing is confirmed, reload the hold counter.
             * Motion stays active until hold_counter counts down to zero. */
            if (has_high && has_low) {
                if (channels[i].hold_counter == 0) {
                    /* Log only the leading edge to avoid flooding the console */
                    DBG(DBG_INFO, "MOTION CH%d", i);
                }
                channels[i].hold_counter      = HOLD_SAMPLES;
                channels[i].stability_counter = 0;
            }

            /* --- Step 5: Stability-based hold decay ---
             * If the signal has been below 50% of threshold for STABLE_SAMPLES
             * consecutive samples, decrement the hold counter faster (by 10
             * instead of 1). This makes the detector react more quickly when
             * the person has clearly left the sensor's field of view. */
            if (abs_centered < threshold * STABILITY_RATIO) {
                channels[i].stability_counter++;
            } else {
                channels[i].stability_counter = 0;
            }

            if (channels[i].stability_counter >= STABLE_SAMPLES
                && channels[i].hold_counter > 0)
            {
                channels[i].hold_counter = (channels[i].hold_counter > 10)
                                           ? channels[i].hold_counter - 10 : 0;
            }

            /* --- Step 6: Update motion flag ---
             * motion_active is true as long as hold_counter > 0. */
            channels[i].motion_active = (channels[i].hold_counter > 0);
            if (channels[i].hold_counter > 0)
                channels[i].hold_counter--;

            if (channels[i].motion_active) any_motion = true;

            /* Track peak values for the diagnostic printout below */
            if (centered > max_c[i]) max_c[i] = centered;
            if (centered < min_c[i]) min_c[i] = centered;
        }

        /* Drive the LED: on = motion detected on at least one channel */
       // HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin,
                        //  any_motion ? GPIO_PIN_SET : GPIO_PIN_RESET);

        /* Diagnostic output — prints peak amplitude and motion state
         * for each channel once per second (200 samples @ 200 Hz).
         * Can be removed in production builds. */
        diag_counter++;
        if (diag_counter >= 200) {
            for (int i = 0; i < ADC_CHANNELS; i++) {
                /*DBG(DBG_INFO, "CH%d: max=%d min=%d thr=%d motion=%d",
                    i, (int)max_c[i], (int)min_c[i],
                    (int)CHANNEL_THRESHOLD[i],
                    (int)channels[i].motion_active);*/
                max_c[i] = 0.0f;
                min_c[i] = 0.0f;
            }
            diag_counter = 0;
        }
    }
}
