/*
 * pir_ys312.c
 *
 *  Created on: Apr 28, 2026
 *      Author: BBoiko
 */

#include "pir_ys312.h"
#include "debug.h"
/* ------------------------------------------------------------------ */
/*  Внутрішні змінні                                                   */
/* ------------------------------------------------------------------ */
static TIM_HandleTypeDef *_htim;        // Таймер для мікросекундних затримок
static PIR_STATE  _state      = PIR_ST_IDLE;
static uint32_t   _timer_start = 0;     // Момент початку поточної фази
static uint32_t   _wait_us    = 0;      // Скільки чекати в поточній фазі
static uint8_t    _bit_index  = 0;      // Поточний біт (0..18)
static uint32_t   _raw_bits   = 0;      // Накопичені біти
static PIR_Data_t _result     = {0};    // Останній валідний результат

/* ------------------------------------------------------------------ */
/*  Допоміжні функції                                                  */
/* ------------------------------------------------------------------ */

/** Отримати поточний мікросекундний лічильник з TIM2 */
static inline uint32_t get_us(void)
{
    return __HAL_TIM_GET_COUNTER(_htim);
}

/** Перевірити чи минув потрібний час */
static inline uint8_t elapsed(uint32_t us)
{
    return (get_us() - _timer_start) >= us;
}

/** Переключити DOCI в режим OUTPUT */
static void DOCI_SetOutput(void)
{
    GPIO_InitTypeDef g = {0};
    g.Pin   = PIR_DOCI_PIN;
    g.Mode  = GPIO_MODE_OUTPUT_PP;
    g.Pull  = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(PIR_DOCI_PORT, &g);
}

/** Переключити DOCI в режим INPUT (без підтяжок - "release") */
static void DOCI_SetInput(void)
{
    GPIO_InitTypeDef g = {0};
    g.Pin   = PIR_DOCI_PIN;
    g.Mode  = GPIO_MODE_INPUT;
    g.Pull  = GPIO_NOPULL;
    HAL_GPIO_Init(PIR_DOCI_PORT, &g);
}

static inline void DOCI_High(void)
{
    HAL_GPIO_WritePin(PIR_DOCI_PORT, PIR_DOCI_PIN, GPIO_PIN_SET);
}

static inline void DOCI_Low(void)
{
    HAL_GPIO_WritePin(PIR_DOCI_PORT, PIR_DOCI_PIN, GPIO_PIN_RESET);
}

static inline uint8_t DOCI_Read(void)
{
    return (uint8_t)HAL_GPIO_ReadPin(PIR_DOCI_PORT, PIR_DOCI_PIN);
}

/* ------------------------------------------------------------------ */
/*  Публічні функції                                                   */
/* ------------------------------------------------------------------ */

void PIR_Init(TIM_HandleTypeDef *htim_us)
{
    _htim  = htim_us;
    _state = PIR_ST_IDLE;
    _result.data_ready = 0;
    _result.error= 0;

    /* Запускаємо таймер якщо ще не запущений */
    HAL_TIM_Base_Start(_htim);

    /* Відпускаємо лінію - PIR сам підніме коли буде готовий */
    DOCI_SetInput();
}

/* ------------------------------------------------------------------ */
void PIR_ProcessLoop(void)
{
    switch (_state)
    {
        /* ---------------------------------------------------------- */
        /* IDLE: лінія відпущена (input), чекаємо поки PIR підніме її */
        /* ---------------------------------------------------------- */
        case PIR_ST_IDLE:
            _result.data_ready = 0;
            _bit_index = 0; // Поточний біт (0..18)
            _raw_bits  = 0; // Накопичені біти
            DOCI_SetInput();
            _state = PIR_ST_WAIT_PIR_HIGH;
            break;


        /* ---------------------------------------------------------- */
        /* Чекаємо HIGH від PIR (він піднімає після оновлення ~16ms)  */
        /* ---------------------------------------------------------- */
        case PIR_ST_WAIT_PIR_HIGH:
            if (DOCI_Read() == 1) {
                /* PIR підняв лінію -> починаємо start signal */
                /* Спочатку виставляємо HIGH на output перед переключенням */
                /*DOCI_High();
                DOCI_SetOutput();*/

                _timer_start = get_us();
                _state = PIR_ST_START_HIGH;
            }
            break;

        /* ---------------------------------------------------------- */
        /* Тримаємо HIGH протягом tS (start signal)                   */
        /* ---------------------------------------------------------- */
        case PIR_ST_START_HIGH:
            if (elapsed(PIR_TS_US)) {
                /* Тягнемо LOW для першого клоку */
            	DBG(DBG_TRACE, "START_HIGH done, going LOW");
                DOCI_Low();
                DOCI_SetOutput();
                _timer_start = get_us();
                _state = PIR_ST_CLK_PULL_LOW;
            }
            break;

        /* ---------------------------------------------------------- */
        /* Клок LOW (tL)                                               */
        /* ---------------------------------------------------------- */
        case PIR_ST_CLK_PULL_LOW:
            if (elapsed(PIR_TL_US)) {
                /* Тягнемо HIGH */
                DOCI_High();
                _timer_start = get_us();
                _state = PIR_ST_CLK_PULL_HIGH;
            }
            break;

        /* ---------------------------------------------------------- */
        /* Клок HIGH (tH), потім відпускаємо лінію                    */
        /* ---------------------------------------------------------- */
        case PIR_ST_CLK_PULL_HIGH:
            if (elapsed(PIR_TH_US)) {
                /* Відпускаємо лінію - PIR виставить біт */
                DOCI_SetInput();
                _timer_start = get_us();
                _state = PIR_ST_WAIT_STABILIZE;
            }
            break;

        /* ---------------------------------------------------------- */
        /* Чекаємо стабілізації біту (tB)                             */
        /* ---------------------------------------------------------- */
        case PIR_ST_WAIT_STABILIZE:
            if (elapsed(PIR_TB_US)) {
                _state = PIR_ST_SAMPLE_BIT;
            }
            break;

        /* ---------------------------------------------------------- */
        /* Читаємо біт (старший біт першим, B18..B0)                  */
        /* ---------------------------------------------------------- */
        case PIR_ST_SAMPLE_BIT:
        {
            uint8_t bit = DOCI_Read();
            DBG(DBG_TRACE, "bit[%d]=%d", _bit_index-1, bit);
            /* Зберігаємо біт (зсуваємо вліво, B18 приходить першим) */
            _raw_bits = (_raw_bits << 1) | bit;
            _bit_index++;

            if (_bit_index >= PIR_TOTAL_BITS) {
                /* Всі 19 біт прочитані -> перевірка заголовку */
                /* B18=1 (біт 18), B17=0 (біт 17), B0=0 (біт 0) */
                uint8_t b18 = (_raw_bits >> 18) & 0x01;
                uint8_t b17 = (_raw_bits >> 17) & 0x01;
                uint8_t b0  = (_raw_bits >> 0)  & 0x01;

                if (b18 == 1 && b17 == 0 && b0 == 0) {
                    /* Валідний пакет - витягуємо 16-бітне знакове значення */
                    /* Біти B16..B1 -> зсуваємо на 1 вправо */
                    uint16_t raw16 = (uint16_t)((_raw_bits >> 1) & 0xFFFF);
                    _result.raw_value  = (int16_t)raw16;
                    _result.data_ready = 1;
                    _result.error      = 0;
                } else {
                    _result.error      = 1;
                    _result.data_ready = 0;
                }

                /* Завершуємо: MCU тягне LOW потім відпускає */
                DOCI_High();
                DOCI_SetOutput();
                DOCI_Low();
                DOCI_SetInput();

                _state = PIR_ST_IDLE;
            } else {
                /* Ще є біти -> наступний клок */
                /* Переключаємось в output перед LOW */
                DOCI_Low();
                DOCI_SetOutput();

                _timer_start = get_us();
                _state = PIR_ST_CLK_PULL_LOW;
            }
            break;
        }

        case PIR_ST_DONE:
        case PIR_ST_ERROR:
            _state = PIR_ST_IDLE;
            break;

        default:
            _state = PIR_ST_IDLE;
            break;
    }
}

/* ------------------------------------------------------------------ */
PIR_Data_t PIR_GetData(void)
{
    PIR_Data_t d = _result;
    _result.data_ready = 0;     // Скидаємо прапор після читання
    return d;
}
