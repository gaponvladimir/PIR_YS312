#include "main.h"
#include "adc_sampler.h"
#include "lwrb.h"
#include "debug.h"
#include "signalFiltering.h"
/** Buffer for one frame that includes all \sa ADC_CHANNEL_COUNT measurement channels */
static uint16_t adc_dma_frame[ADC_CHANNEL_COUNT];

/** Circular buffer structure */
static lwrb_t adc_rb;

/** Byte buffer used as ring buffer for store sample frames from PIR sensors */
static uint8_t adc_rb_mem[ADC_RINGBUF_FRAMES  * ADC_FRAME_SIZE];


/*-----------------------------------------------------------------------------------*/
/** Initialize ADC1 PIR sensor acquisition mechanism
 *
 * In our case TIMER1 used for generating Trigger event for start ADC conversion
 * for all PIR sensors measurement channels.
 * Function will initialize circular buffer structure.
 * Start ADC calibration.
 * Start ADC DMA acquation for 4 single-ended analog channels.
 * Start TIMER1 configured for generating udate event every 200Hz taht will pass as TRIG event for ADC1.
 *
 * \return	None
 */
void adc_manager_init(void)
{
	// Initialize circular buffer for all 4-channel samples
    lwrb_init(&adc_rb, adc_rb_mem, sizeof(adc_rb_mem));

    // Calibrate ADC1
    HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED);

    // Start ADC1 for 4-channel sampling
    HAL_ADC_Start_DMA(&hadc1, (uint32_t *) adc_dma_frame, ADC_CHANNEL_COUNT);


    // Start our channel sampling timer
    HAL_TIM_Base_Start_IT(&htim1);

}

/*-----------------------------------------------------------------------------------*/
/** Callback functionality that will process ADC conversion complete event
 *
 * Function check if there is a space in the circular buffer for one sample frame.
 * If not function will release on frame from the circular buffer an allow to write new
 * sampled data frame.
 *
 * \param	hadc	Pointer to the ADC structure that is used in measurement and DMA data transfer
 */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc)
{
    if (hadc == &hadc1) {

    	// Check if we have room for store new frame in circular buffer
    	if (lwrb_get_free(&adc_rb) < ADC_FRAME_SIZE) {
    		// Pop one frame circular buffer
    		lwrb_skip(&adc_rb, ADC_FRAME_SIZE);
    	}

    	// Write new frame into the circular buffer
        lwrb_write(&adc_rb, (uint8_t *) adc_dma_frame, ADC_FRAME_SIZE);

        Signal_PushData(adc_dma_frame, ADC_CHANNEL_COUNT);


    }
}


/*-----------------------------------------------------------------------------------*/
/** Read specified amount of PIR sample frames (4-channels) to the specified location
 *
 * \param	ptr_buf						Pointer to the byte array where to reload PIR-sensors frames
 * \param	amount_of_frames_to_read	Amount of 4-channels frames to read from circular buffer
 * \param	buf_size					Size of the buffer where we reload frames
 * \return								Amount of data bytes reloaded, or -1 if error detected
 */
int adc_sampler_get(uint8_t *ptr_buf, uint32_t amount_of_frames_to_read, uint32_t buf_size)
{
	uint32_t data_in_buffer, frames_in_buffer;
	uint32_t read;


	// If pointer to the buffer where to reload data is not valid
	if (ptr_buf == 0) {
		// Return error
		return (-1);
	}

	// Get amount of data bytes resides in the circular buffer
	data_in_buffer = lwrb_get_full(&adc_rb);
	// Get amount of available frames
	frames_in_buffer = data_in_buffer / ADC_FRAME_SIZE;

	// If user specified amount of frames to read is equal to zero
	if (amount_of_frames_to_read == 0) {
		// we need to output all available data
		amount_of_frames_to_read = frames_in_buffer;
	}

	// If in our circular buffer resides more data that we can reload to supplied buffer
	if (amount_of_frames_to_read > (buf_size / ADC_FRAME_SIZE)) {
		// Specify max allowed to read from circular buffer
		amount_of_frames_to_read = buf_size / ADC_FRAME_SIZE;
	}

	// Read specified amount of frames
	read = lwrb_read(&adc_rb, ptr_buf, amount_of_frames_to_read * ADC_FRAME_SIZE);

    return read;
}
