#include "main.h"
#include "debug.h"
#include "cmd_processing.h"
#include "helper.h"
#include "atomic.h"
#include "adc_sampler.h"

/** Buffer used for store command with parameters for further processing */
unsigned char command_for_processing[CMD_BUFFER_SIZE];
/** Length of the received for processing command and data fields excluding LRC field */
unsigned int command_length;

/** Buffer used for store answer to received command */
unsigned char answer_to_command[CMD_BUFFER_SIZE];
/** Size of the created answer in the \sa answer_to_command buffer that needs to be send to host */
unsigned int answer_size = 0;

/** Temporary buffer that is used in communication during command processing */
unsigned char tmp_buf[1024];

int process_logic_command(void);

const char dbg_header[] = "CMD_PROCESSING:";

/*-----------------------------------------------------------------------------------*/
unsigned int cmd_get_amount_in_queue(ringbuff_t *cmd_buf)
{
	return lwrb_get_full(cmd_buf);
}

/*-----------------------------------------------------------------------------------*/
/** Check for SOF in the ring buffer
 *
 * \param	cmd_buf	Pointer to the ring buffer where the SOF must resides
 * \return			'0' - SOF exist in the specified buffer
 * 					'-1' - any data is absent in the specified buffer
 * 					'-2' - first byte is not equal to the valid SOF (all data is purged)
 */
BUF_PROCESSING_STATUS cmd_check_for_sof(ringbuff_t *cmd_buf)
{
	unsigned char sof_char = 0xFF;

	// Check if amount of data in the supplied circular buffer enough to contain SOF character
	if (lwrb_get_full(cmd_buf) > 0) {
		ATOMIC() {
			// Read one character that must be SOF
			lwrb_peek(cmd_buf, 0, &sof_char, 1);
		}

		// If received first byte of the command sequence equal to SOF
		if (sof_char == CMD_SOF) {
			// Return success
			return (BUF_PROC_OK);
		}
		// Else return we need to purge received sequence -> there was an error in communication
		// Every time the first element in the queue must be equal to SOF
		else {
			CMD_DEBUG(DBG_WARNING, "%s First received byte ('0x%02X') is not a SOF. Purge buffer", dbg_header, sof_char);
			lwrb_reset(cmd_buf);
			return (BUF_PROC_SOF_INVALID);
		}
	}
	// Data is absent in USB buffer
	else {
		return (BUF_PROC_DATA_ABSENT);
	}
}

/*-----------------------------------------------------------------------------------*/
int cmd_get_data_length(ringbuff_t *cmd_buf)
{
	unsigned char data_length[2];
	unsigned short len = 0;

	// Check if amount of data in the supplied circular buffer enough to contain SOF character + data length field
	if (lwrb_get_full(cmd_buf) >= 3) {
		ATOMIC() {
			// Read two bytes that must be packet data length (skip first SOF byte)
			lwrb_peek(cmd_buf, 1, &data_length, 2);
		}
	}
	// At this moment circular buffer does not contain data length field
	else {
		return (0);
	}
	// Convert MSB & LSB to the short value
	len = (unsigned short) (data_length[0] << 8) + data_length[1];
	// Check the length that is not greater then max size
	if (len > CMD_BUFFER_SIZE) {
		// Return error
		CMD_DEBUG(DBG_ERROR, "%s Received (invalid) data length (%d)", dbg_header, len);
		return (-1);
	}

	//CMD_DEBUG(DBG_TRACE, "%s Received data length %d", dbg_header, len);

	// Return the length of the data section
	return (int) len;
}

/*-----------------------------------------------------------------------------------*/
int cmd_check_if_command_received(ringbuff_t *cmd_buf, unsigned int len)
{
	unsigned int total_packet_size;

	// Get amount of data currently resides in the circular buffer
	total_packet_size = lwrb_get_full(cmd_buf);

	// If the current size of the received packet resides in the buffer
	// is equal to packet length field + packet header size -> packet received
	if (total_packet_size >= len + CMD_HEADER_SIZE) {
		// Definitely we have already one packet received in the circular buffer
		return (0);
	}
	// Packet is not currently received
	return (-1);
}

/*-----------------------------------------------------------------------------------*/
void cmd_purge_queue_buffer(ringbuff_t *cmd_buf)
{
	ATOMIC() {
		lwrb_reset(cmd_buf);
	}
}

/*-----------------------------------------------------------------------------------*/
/** Calculate CRC8 for specified data portion with polynomial equal to \sa CMD_CRC_POL
 *
 * \param	data 		Pointer to the data portion
 * \param length	Length of the data portion
 * \return 				CRC8 value
 */
uint8_t cmd_calculate_crc8(unsigned char *data, unsigned int length)
{
	unsigned char fb, cnt, byte, crc = 0;
	unsigned int i;

	for(i = 0; i < length; i++) {
		byte = data[i];
		cnt = 8;

		while (cnt--){
			fb = (crc ^ byte) & 0x01;
			if (fb == 0x01) {
				crc ^= CMD_CRC_POL;
			}
			crc = (crc >> 1) & 0x7F;
			if (fb == 0x01) {
				crc |= 0x80;
			}
			byte >>= 1;
		}
	}
	return crc;
}

/*-----------------------------------------------------------------------------------*/
/** Validate received packet functionality.
 *
 * Function tries validate packet received into specified circular buffer by the next aspects:
 * 1. SOF byte exist and it equals to zero.
 * 2. Amount of received data is greater then (\sa CMD_HEADER_SIZE + \sa CMD_COMMAND_FIELD_SIZE + \sa CMD_LRC_FIELD_SIZE)
 * 3. Packet Length specified in the header is equal to received data + \sa CMD_HEADER_SIZE
 * 4. Calculated CRC for received data is equal to the CRC that appended to the packet
 *
 * If one of the criteria is not valid function will return negative value
 *
 * \param	cmd_buf	Pointer to the circular buffer where received packet resides
 * \return	'BUF_PROC_OK' - if packet exist in circular buffer and successfully validated
 * 			'BUF_PROC_DATA_ABSENT' - data is absent in the circular buffer
 * 			'BUF_PROC_SOF_INVALID' - first byte in circular buffer was not equal to the SOF (all data rejected)
 * 			'BUF_PROC_IN_RECEPTION' - data partially received (received size is less then size of header+cmd+CRC)
 * 			'BUF_PROC_LENGTH_INVALID' - specified length in the packet is not valid (greater then buffer size)
 * 			'BUF_PROC_CRC_INVALID' - CRC calculated for packet is not equal to included in the packet
 */
BUF_PROCESSING_STATUS cmd_validate_packet(ringbuff_t *cmd_buf)
{
	unsigned int total_packet_size;
	unsigned char header[3];
	unsigned short data_length;
	unsigned char received_CRC8, calculated_CRC8;
	unsigned int packet_size;
	int status;

	// Reset amount of received data into the command for processing buffer before validation
	command_length = 0;

	// Check if SOF exist in received packet
	status = cmd_check_for_sof(cmd_buf);
	// If data is not available in buffer (-1) or SOF invalid (-2)
	if (status < 0) {
		return (status);
	}

	// Get amount of data available in the circular buffer
	total_packet_size = lwrb_get_full(cmd_buf);

	// Check if data enough in received packet for further processing
	if (total_packet_size < (CMD_HEADER_SIZE + CMD_LRC_FIELD_SIZE + CMD_COMMAND_FIELD_SIZE)) {
		CMD_DEBUG(DBG_WARNING, "%s Warning. Amount of data (%d) is not enough for processing\n", dbg_header, total_packet_size);
		return (BUF_PROC_IN_RECEPTION);
	}

	// Read header into the temporary buffer without modification read pointer (packet data may not be fully received yet)
	ATOMIC() {
		lwrb_peek(cmd_buf, 0, header, CMD_HEADER_SIZE);
	}
	// Get data length
	data_length = (unsigned short) (header[1] << 8) + header[2];

	// Check packet length
	packet_size = data_length + CMD_HEADER_SIZE;
	// Check if packet is greater then our command processing buffer
	if (data_length > CMD_BUFFER_SIZE) {
		CMD_DEBUG(DBG_ERROR, "%s Error. Packet data length (%d) is greater then processing buffer", dbg_header, data_length);
		// Remove received data
		lwrb_reset(cmd_buf);
		return (BUF_PROC_LENGTH_INVALID);
	}
	if (total_packet_size < packet_size) {
		CMD_DEBUG(DBG_WARNING, "%s Warning. Packet length (%d) is less then bytes in buffer (%d)", dbg_header, packet_size, total_packet_size);
		return (BUF_PROC_IN_RECEPTION);
	}

	// If we are there - header is validated and data amount in buffer is exact that specified in the length field -> move to the command field
	lwrb_skip(cmd_buf, CMD_HEADER_SIZE);

	// ALL OK: header valid, data length valid -> reload command + data + lrc into the processing buffer
	ATOMIC() {
		lwrb_read(cmd_buf, command_for_processing, data_length);
	}

	//CMD_DUMP(DBG_DEBUG, command_for_processing, (data_length > 32 ? 32 : data_length), "%s CMD/DATA: ", dbg_header);

	// Calculate CRC8 for CMD field + Data field
	calculated_CRC8 = cmd_calculate_crc8(command_for_processing, data_length - 1);

	// Get received CRC8 from received packet
	received_CRC8 = command_for_processing[data_length - 1];

	// Compare calculated CRC8 with received
	if (calculated_CRC8 != received_CRC8) {
		CMD_DEBUG(DBG_ERROR, "%s Error. Received CRC (0x%02X) not equal to calculated CRC (0x%02X)", dbg_header, received_CRC8, calculated_CRC8);
		return (BUF_PROC_CRC_INVALID);
	}
	// Set amount of received data for processing ([CMD]+[DATA]) excluding LRC
	command_length = data_length - CMD_LRC_FIELD_SIZE;

	CMD_DEBUG(DBG_DEBUG, "%s Received packet validated\n", dbg_header);

	return 0;
}


/*-----------------------------------------------------------------------------------*/
int cmd_set_answer(unsigned char cmd, CMD_ANSWER_STATUS status, unsigned char *data, unsigned int data_length)
{
	unsigned int packet_length, data_length_field;
	unsigned char CRC8;

	// If data is not supplied -> set data length to zero
	if (data == 0) {
		data_length = 0;
	}

	// Prepare header -> Set SOF
	answer_to_command[0] = CMD_SOF;
	// Add command number to the packet
	CMD_ANSWER_SET_COMMAND(cmd);

	// If length of data section plus additional payload is greater then size of our answer buffer
	if( (data_length + CMD_HEADER_SIZE + CMD_COMMAND_FIELD_SIZE + CMD_STATUS_FIELD_SIZE) > sizeof(answer_to_command) )        {
		// Set length of the error answer
		CMD_ANSWER_SET_LENGTH(2);
		// Set status to -> buffer to small
		CMD_ANSWER_SET_STATUS(CMD_STATUS_BUFFER_TO_SMALL);
		// Set the overall packet size (header + cmd + status + lrc)
		packet_length = CMD_HEADER_SIZE	+ CMD_COMMAND_FIELD_SIZE + CMD_STATUS_FIELD_SIZE + CMD_LRC_FIELD_SIZE;
	} else {
		// Add command execution status to the packet
		CMD_ANSWER_SET_STATUS(status);
		if (data != 0) {
			// Add supplied data to the packet
			CMD_ANSWER_SET_DATA(data, data_length);
		}
		// Set overall packet size (header + cmd + status + data + lrc)
		packet_length = data_length + CMD_HEADER_SIZE + CMD_COMMAND_FIELD_SIZE + CMD_STATUS_FIELD_SIZE + CMD_LRC_FIELD_SIZE;
	}

	// Calculate amount that must be specified in Packet Data Length Field = data length + cmd + lrc
	data_length_field = packet_length - CMD_HEADER_SIZE;
	// Set Packet Data Length Field
	CMD_ANSWER_SET_LENGTH(data_length_field);
	// Calculate CRC8 for (Command + Status + Data)
	CRC8 = cmd_calculate_crc8(&answer_to_command[3], data_length_field - 1);
	// Insert CRC8
	answer_to_command[packet_length - 1] = CRC8;
	// Save amount of data that is resides in the answer buffer
	answer_size = packet_length;

	//CMD_DUMP(DBG_TRACE, answer_to_command, (answer_size > 32 ? 32 : answer_size), "Answer on command %02X; status %d, size %d => ", cmd, status, answer_size);

	return packet_length;
}

/*-----------------------------------------------------------------------------------*/
int cmd_append_data_to_answer(unsigned char *data, unsigned int data_length)
{
	unsigned int data_length_field;
	unsigned char CRC8;

	// If data provided as arguments exists
	if (data_length && data) {
		// Check if length of our buffer is not enough to store supplied data
		if ((answer_size + data_length) > sizeof(answer_to_command)) {
			return(-1);
		}
		// Append data to the end of the answer buffer (starting on the position where previous LRC was placed)
		memcpy(&answer_to_command[answer_size - 1], data, data_length);
		// Set new value of all amount of data resides in answer buffer
		answer_size += data_length;
		// Calculate amount that must be specified in Packet Data Length Field = data length + cmd + lrc
		data_length_field = answer_size - CMD_HEADER_SIZE;
		// Set new Packet Data Length Field
		CMD_ANSWER_SET_LENGTH(data_length_field);
		// Calculate CRC8 for (Command + Status + Data)
		CRC8 = cmd_calculate_crc8(&answer_to_command[3], data_length_field - 1);
		// Insert CRC8
		answer_to_command[answer_size - 1] = CRC8;
	}

	return answer_size;
}


/*-----------------------------------------------------------------------------------*/
int cmd_process_received_command(void)
{
	unsigned char command = command_for_processing[0];
	//unsigned char cnt;
	//unsigned int tmp, length = 0;
	//unsigned short value;
	int answer;
	uint32_t tmp;
    //int status;


	// Reset the counter of data amount resides in answer buffer before processing command
	answer_size = 0;

	CMD_DEBUG(DBG_DEBUG,
	    "CMD received: 0x%02X, data_len=%d",
	    command,
	    command_length > 0 ? (command_length - 1) : 0
	);
	switch(command) {
		// GET DEVICE SERIAL NUMBER
		case CMD_GET_SERIAL_NUMBER:
			CMD_DEBUG(DBG_DEBUG, "%s Get Serial number", dbg_header);
			// Get serial number
			if ((answer = Get_Serial((char *)tmp_buf, sizeof(tmp_buf))) < 0) {
				// If it can't be extracted	from OTP -> set Serial to "000000"
				memset(tmp_buf, '0', SERIAL_NUMBER_SIZE - 1);
				tmp_buf[SERIAL_NUMBER_SIZE] = 0;
				answer = SERIAL_NUMBER_SIZE - 1;
			}
			// Construct answer in the buffer that will be transmitted back to the host
			cmd_set_answer(command, CMD_STATUS_SUCCESS, tmp_buf, answer);
			break;

		// GET HARDWARE VERSION X.Y
		case CMD_GET_HARDWARE_VERSION:
			CMD_DEBUG(DBG_DEBUG, "%s Get Hardware version\n", dbg_header);
			// Get hardware version, if error - fill by answer by "-.-"
			if(Get_Hardware_Revision((char*)tmp_buf, sizeof(tmp_buf)) < 0){
				tmp_buf[0] = '-';   tmp_buf[1] = '.';   tmp_buf[2] = '-';   tmp_buf[3] = 0;
			}
			answer = strlen((char*)tmp_buf);
			cmd_set_answer(command, CMD_STATUS_SUCCESS, tmp_buf, answer);
			break;

		// GET Firmware VERSION X.Y.Z (Major.Minor.revision)
		case CMD_GET_FIRMWARE_VERSION:
			CMD_DEBUG(DBG_DEBUG, "%s Get Firmware version\n", dbg_header);
			if(Get_Firmware_Version((char*)tmp_buf, sizeof(tmp_buf)) == 0){
				answer = strlen((char*)tmp_buf);
				cmd_set_answer(command, CMD_STATUS_SUCCESS, tmp_buf, answer);
			}
			else {
				cmd_set_answer(command, CMD_STATUS_ERROR, 0, 0);
			}
			break;




/*
		case CMD_SET_TIMEOUT_INTERVAL:
			CMD_DEBUG(DBG_DEBUG, "%s Set timeout interval\n", dbg_header);
			processing_timeout = short_from_bytes_big_endian(&command_for_processing[1]);
			CMD_DEBUG(DBG_DEBUG, "%s Timeout interval is %d ms\n", dbg_header, processing_timeout);
			// Check timeout value for validity: 300ms ... 5sec
			if ((processing_timeout > 5000) || (processing_timeout < 300)) {
                // If not supported set to default value
                processing_timeout = DEFAULT_PROCESSING_TIMEOUT;
                CMD_DEBUG(DBG_WARNING, "%s Timeout interval invalid. Set to default %d ms\n", dbg_header, processing_timeout);
                cmd_set_answer(command, CMD_STATUS_ERROR, 0, 0);
			}
            else {
				cmd_set_answer(command, CMD_STATUS_SUCCESS, 0, 0);
			}
			break;

		case CMD_GET_TIMEOUT_INTERVAL:
			CMD_DEBUG(DBG_DEBUG, "%s Get timeout interval\n", dbg_header);
			short_to_bytes_big_endian(processing_timeout, tmp_buf);
			cmd_set_answer(command, CMD_STATUS_SUCCESS, tmp_buf, 2);
			break;
*/
/*
		// WRITE VARIABLE INTO ENVIRONMENT
		case CMD_WRITE_ENVIRONMENT:
			CMD_DEBUG(DBG_DEBUG, "%s Write a variable into CPU environment\n", dbg_header);
			// call write environment function, send data buffer pointer and data length
			if(Write_CPU_Environment((char*)&command_for_processing[1], command_length - 1) < 0){
				cmd_set_answer(command, CMD_STATUS_ERROR, 0, 0);
			}
			else {
				cmd_set_answer(command, CMD_STATUS_SUCCESS, 0, 0);
		  }
			break;
*/
/*
        // Reset whole device
        case CMD_RESET_DEVICE:
            CMD_DEBUG(DBG_DEBUG, "%s Reset Device\n", dbg_header);

            // set device reset mode
            Device_Reset_Mode();
            // Display "Resetting device" on the LCD
            Display_Device_Reset();
            // Answer that command executed successfully
            cmd_set_answer(command, CMD_STATUS_SUCCESS, 0, 0);
            break;
*/
/*
        // Reload device settings from device flash memory
		case CMD_RELOAD_SETTINGS:
			CMD_DEBUG(DBG_DEBUG, "%s Reload device settings\n", dbg_header);
			// Reload device settings from external storage
			answer = load_device_settings();
			if (answer < 0) {
				// Prepare answer that command executed with error
				cmd_set_answer(command, CMD_STATUS_ERROR, 0, 0);
			} else {
				// Answer that command executed successfully
				cmd_set_answer(command, CMD_STATUS_SUCCESS, 0, 0);
			}
			break;
*/
/*
        // READ VARIABLE FROM ENVIRONMENT
		case CMD_READ_ENVIRONMENT:
			CMD_DEBUG(DBG_DEBUG, "%s Read a variable from CPU environment\n", dbg_header);
			// call read environment function, send data buffer pointer and data length
			if((answer = Read_CPU_Environment((char*)&command_for_processing[1], (char*)tmp_buf, sizeof(tmp_buf))) < 0){
				cmd_set_answer(command, CMD_STATUS_ERROR, 0, 0);
			} else {
				cmd_set_answer(command, CMD_STATUS_SUCCESS, tmp_buf, answer);
			}
			break;
*/
/*
		case CMD_USER_LED_RGB:
			CMD_DEBUG(DBG_DEBUG, "%s Set RGB color of user LED\n", dbg_header);
			cmd_set_answer(command, CMD_STATUS_ERROR, 0, 0);
			break;
*/

		case CMD_SET_SYSTEM_TIME:
			CMD_DEBUG(DBG_DEBUG, "%s Set system time\n", dbg_header);
			if(Set_System_Time((char*)&command_for_processing[1]) < 0){
				cmd_set_answer(command, CMD_STATUS_ERROR, 0, 0);
			} else {
				cmd_set_answer(command, CMD_STATUS_SUCCESS, 0, 0);
				CMD_DEBUG(DBG_DEBUG,"%s Time set\n",dbg_header);
			}
			break;

		case CMD_GET_SYSTEM_TIME:
			CMD_DEBUG(DBG_DEBUG, "%s Get system time\n", dbg_header);
			answer = Get_System_Time(&tmp);
			if(answer < 0){
				CMD_DEBUG(DBG_ERROR, "%s Can't get system time\n", dbg_header);
				cmd_set_answer(command, CMD_STATUS_ERROR, 0, 0);
			} else {
				integer_to_bytes_big_endian(tmp, tmp_buf);
				cmd_set_answer(command, CMD_STATUS_SUCCESS, tmp_buf, 4);
			}
			break;

		// Get available frame data from all four PIR sensors
		case CMD_GET_ADC_DATA:{
			CMD_DEBUG(DBG_DEBUG, "%s Read PIR sensors data\n", dbg_header);
			answer = adc_sampler_get(tmp_buf, 0, sizeof(tmp_buf));

			 CMD_DEBUG(DBG_DEBUG,
			              "%s adc_sampler_get -> %d bytes",
			              dbg_header, answer);
			if(answer < 0){
				CMD_DEBUG(DBG_ERROR, "%s Can't read data\n", dbg_header);
				cmd_set_answer(command, CMD_STATUS_ERROR, 0, 0);

			}
			else {
				cmd_set_answer(command, CMD_STATUS_SUCCESS, tmp_buf, answer);
			}
			break;
		}


        // UNKNOWN command
        default:
            CMD_DEBUG(DBG_DEBUG, "%s Unknown command (%02X)\n", dbg_header, command);
            // This command is not supported
            cmd_set_answer(command, CMD_STATUS_UNKNOWN, 0, 0);
            break;
    }
    return answer_size;
}

/*-----------------------------------------------------------------------------------*/
unsigned char* cmd_get_answer_for_command(void)
{
	return answer_to_command;
}

/*-----------------------------------------------------------------------------------*/
// return: 0 - Not data available yet (we need to wait for specified waiting timeout)
// return: >0 - amount of data for transmit to host transmit
int cmd_wait_for_command_answer(unsigned int timeout_start, unsigned int timeout_to_wait)
{
	//unsigned char inQueue;
	//int status_answer_len;
    //unsigned int len;
    //unsigned int tick_value;
    //unsigned char* ptr = 0;
    //uint8_t command = command_for_processing[0];
    int anser_size = 0;

	return answer_size;
}
