################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Src/adc_sampler.c \
../Core/Src/cmd_processing.c \
../Core/Src/debug.c \
../Core/Src/helper.c \
../Core/Src/lwrb.c \
../Core/Src/main.c \
../Core/Src/pir_ys312.c \
../Core/Src/signalFiltering.c \
../Core/Src/stm32g4xx_hal_msp.c \
../Core/Src/stm32g4xx_it.c \
../Core/Src/syscalls.c \
../Core/Src/sysmem.c \
../Core/Src/system_stm32g4xx.c 

OBJS += \
./Core/Src/adc_sampler.o \
./Core/Src/cmd_processing.o \
./Core/Src/debug.o \
./Core/Src/helper.o \
./Core/Src/lwrb.o \
./Core/Src/main.o \
./Core/Src/pir_ys312.o \
./Core/Src/signalFiltering.o \
./Core/Src/stm32g4xx_hal_msp.o \
./Core/Src/stm32g4xx_it.o \
./Core/Src/syscalls.o \
./Core/Src/sysmem.o \
./Core/Src/system_stm32g4xx.o 

C_DEPS += \
./Core/Src/adc_sampler.d \
./Core/Src/cmd_processing.d \
./Core/Src/debug.d \
./Core/Src/helper.d \
./Core/Src/lwrb.d \
./Core/Src/main.d \
./Core/Src/pir_ys312.d \
./Core/Src/signalFiltering.d \
./Core/Src/stm32g4xx_hal_msp.d \
./Core/Src/stm32g4xx_it.d \
./Core/Src/syscalls.d \
./Core/Src/sysmem.d \
./Core/Src/system_stm32g4xx.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Src/%.o Core/Src/%.su Core/Src/%.cyclo: ../Core/Src/%.c Core/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../Core/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../Drivers/CMSIS/Include -I../USB_Device/App -I../USB_Device/Target -I../Middlewares/ST/STM32_USB_Device_Library/Core/Inc -I../Middlewares/ST/STM32_USB_Device_Library/Class/CDC/Inc -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Src

clean-Core-2f-Src:
	-$(RM) ./Core/Src/adc_sampler.cyclo ./Core/Src/adc_sampler.d ./Core/Src/adc_sampler.o ./Core/Src/adc_sampler.su ./Core/Src/cmd_processing.cyclo ./Core/Src/cmd_processing.d ./Core/Src/cmd_processing.o ./Core/Src/cmd_processing.su ./Core/Src/debug.cyclo ./Core/Src/debug.d ./Core/Src/debug.o ./Core/Src/debug.su ./Core/Src/helper.cyclo ./Core/Src/helper.d ./Core/Src/helper.o ./Core/Src/helper.su ./Core/Src/lwrb.cyclo ./Core/Src/lwrb.d ./Core/Src/lwrb.o ./Core/Src/lwrb.su ./Core/Src/main.cyclo ./Core/Src/main.d ./Core/Src/main.o ./Core/Src/main.su ./Core/Src/pir_ys312.cyclo ./Core/Src/pir_ys312.d ./Core/Src/pir_ys312.o ./Core/Src/pir_ys312.su ./Core/Src/signalFiltering.cyclo ./Core/Src/signalFiltering.d ./Core/Src/signalFiltering.o ./Core/Src/signalFiltering.su ./Core/Src/stm32g4xx_hal_msp.cyclo ./Core/Src/stm32g4xx_hal_msp.d ./Core/Src/stm32g4xx_hal_msp.o ./Core/Src/stm32g4xx_hal_msp.su ./Core/Src/stm32g4xx_it.cyclo ./Core/Src/stm32g4xx_it.d ./Core/Src/stm32g4xx_it.o ./Core/Src/stm32g4xx_it.su ./Core/Src/syscalls.cyclo ./Core/Src/syscalls.d ./Core/Src/syscalls.o ./Core/Src/syscalls.su ./Core/Src/sysmem.cyclo ./Core/Src/sysmem.d ./Core/Src/sysmem.o ./Core/Src/sysmem.su ./Core/Src/system_stm32g4xx.cyclo ./Core/Src/system_stm32g4xx.d ./Core/Src/system_stm32g4xx.o ./Core/Src/system_stm32g4xx.su

.PHONY: clean-Core-2f-Src

